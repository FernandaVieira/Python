# Les constructeurs

# Les constructeurs ne sont pas des méthodes mais leur traitement est relativement semblable.
# En Python, ce sont des méthodes ayant pour nom __init__. Ils sont automatiquement
# exécutés lors de la création d'un objet.

# Dans la section "Instancier un objet" nous avons dit que pour créer un objet, on utilisait
# la syntaxe suivante (pour un objet de type Voiture): une_voiutre = Voiture()

# Jusqu'à maintenant, nous avons utilisés des constructeurs sans paramètres. On peut cependant,
# comme n'importe quelle autre méthode ou fonction, passer des paramètres au constructeur. Cela permet
# d'initialiser l'objet avec certaines valeurs dès sa création plutôt que d'avoir des valeurs par défaut.

# Pour la classe Voiture, on pourrait alors avoir le constructeur suivant:

class Voiture:
    def __init__(self, no_serie, marque, modele, annee, km, prix):
        self.no_serie = no_serie
        self.marque = marque
        self.modele = modele
        self.annee = annee
        self.km = km
        self.prix = prix

    def imprimer_voiture(self):
        print("{} \t {} \t {} \t {} \t {} \t {}".format(
            self.no_serie,
            self.marque,
            self.modele,
            self.annee,
            self.km,
            self.prix
        ))


# Ainsi, je vais pouvoir créer mes objets Voiture en leur passant en paramètre les valeurs initiales
# qui leur sont propres, ce qui est beaucoup plus efficace que de créer un objet par défaut
# et ensuite affecter ses attributs…

# Pour utiliser le constructeur, on utilise la syntaxe suivante:
# une_voiture = Voiture("Honda", "Civic", 1999, 42000, 17000)

# Un exemple:

if __name__ == "__main__":
    une_voiture = Voiture("1", "Honda", "Civic", 1999, 42000, 17000)
    une_voiture.imprimer_voiture()

    une_voiture.km += 5000

    une_voiture.imprimer_voiture()

# Suite dans concessionnairev1.py


