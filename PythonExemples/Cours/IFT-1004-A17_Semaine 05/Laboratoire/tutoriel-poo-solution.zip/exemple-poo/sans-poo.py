# Si vous avez un système de gestion de voitures (application),
# il serait intéressant de pouvoir créer des variables (instances) de ce type,
# ainsi, vous pourriez faire référence aux différentes caractéristiques de
# celles-ci plus aisément.

# Si les caractéristiques que nous voulons représenter pour une voiture sont les suivantes :

# - marque
# - modèle
# - année
# - kilométrage
# - prix

# On peut procéder à l’ancienne méthode (méthode que l’on connaît), c’est-à-dire que
# l’on peut se créer un paquet de variables pour chacune des voitures que nous
# entrerons dans notre système.  Par exemple, si j’ai les voitures suivantes à entrer dans mon système :

# 1. Honda Civic 1999, 42000 km, 17000$
# 2. Pontiac Sunfire 1996, 93000 km, 8000$
# 3. Toyota Tercel 1996, 81000 km, 8500$
# 4. Dodge Neon 1997, 66000 km, 7000$

# Si je procède à l’ancienne méthode, je devrai alors créer les variables suivantes :

marque1 = "Honda"
modele1 = "Civic"
annee1 = 1999
km1 = 42000
prix1 = 17000

marque2 = "Pontiac"
modele2 = "Sunfire"
annee2 = 1996
km2 = 93000
prix2 = 8000

marque3 = "Toyota"
modele3 = "Tercel"
annee3 = 1996
km3 = 81000
prix3 = 8500

marque4 = "Dodge"
modele4 = "Neon"
annee4 = 1997
km4 = 66000
prix4 = 7000

# Donc on voit ici que pour 4 voitures, j’ai besoin de 20 variables, c’est beaucoup de
# variables pour très peu d’informations, imaginez si votre système de gestion contenait
# 300 voitures, vous auriez besoin de 1500 variables, ce qui est énorme…

# Suite dans le fichier voiturev1.py

