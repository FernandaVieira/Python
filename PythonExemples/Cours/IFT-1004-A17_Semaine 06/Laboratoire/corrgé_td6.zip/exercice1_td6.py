
def somme(nombres):
    '''
    Calcule la somme d'une liste appelee nombres
    :param nombres: liste de nombres
    :return: la somme s
    '''
    s = 0
    for element in nombres:
        s = s + element
    return s


if __name__ == '__main__':

    liste = [-1,5,-3,5,5,2,10,-20]
    print('la somme de {} est {}'.format([1,4], somme([1,4])))

