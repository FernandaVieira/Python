
def uniques1(liste):
    elements_uniques = []
    for el in liste:
        if liste.count(el) == 1:
            elements_uniques.append(el)
    return elements_uniques

def unique2(liste):
    '''
    exercice 2 td 6
    :param liste: liste de nombres
    :return: liste des elemenets uniques
    '''
    occurences = dict(Counter(liste))
    elements_uniques1 = [key for key in occurences if occurences[key] == 1]
    return elements_uniques1

from collections import Counter

if __name__ == '__main__':
    liste = [1,2,3,3]
    elements_uniques0 = uniques1(liste)
    elements_uniques1 = unique2(liste)
    print('les elements uniques de {} sont {}'.format(liste, elements_uniques0))
    print('les elements uniques de {} sont {}'.format(liste, elements_uniques1))