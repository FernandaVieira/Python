
from collections import Counter

def suppr_doublons(liste):
    '''
    supprime les doublons
    :param liste: liste avec doublons
    :return: liste sans doublons
    '''
    cible = []
    for el in liste:
        if el not in cible:
            cible.append(el)
    return cible

def suppr_doublons2(liste):
    return list(dict(Counter(liste)).keys())

def suppr_doublons3(liste):
    # culture generale , utilisation de set
    return list(set(liste))

if __name__ == '__main__':

    liste = [1,2,3,2,3,2,3,3,3,3,4]

    print('sans doubleons {}'.format(suppr_doublons(liste)))
    print(suppr_doublons2(liste))

    s = list(set(liste))
    print(s)
