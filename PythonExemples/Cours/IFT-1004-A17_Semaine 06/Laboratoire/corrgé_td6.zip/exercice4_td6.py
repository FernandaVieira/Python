

def separer_liste(liste, index):
    '''
    splitter une liste par un index
    :param liste: liste a splitter
    :param index: position de separation
    :return: (liste1, liste2)
    '''
    return liste[:index], liste[index:]

from collections import Counter
from ast import literal_eval

if __name__ == '__main__':

    p = 3
    liste = [1,2,3,4,5]

    print(liste[:p], "jusqu'a l'indice {}".format(p-1))
    print(liste[p:], "demarre a l'indice {}".format(p))

    print(separer_liste(liste, p))
    A,B = separer_liste(liste, p)
    print(A, B)

    C, _ = separer_liste(liste, p)
    print(C)

    _ , D = separer_liste(liste, p)
    print(D)

    E = separer_liste(liste, p)
    print(E)
    """
    on ouvre la parenthese
    """
    liste2 =[[2,3] , [2,3], [1], []]
    d3 = dict(Counter([i.__repr__() for i in liste2]))
    L = [literal_eval(key) for key in d3]
    """
    """
    print(liste2 , L)
    exit()

    print(type(literal_eval("[2,1,1]")))

    d2 = dict()
    d2[1] = liste2[0]
    print(d2)