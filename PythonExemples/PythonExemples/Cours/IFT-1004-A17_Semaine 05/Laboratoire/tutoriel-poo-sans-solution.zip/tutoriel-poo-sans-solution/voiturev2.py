# Les méthodes

# On peut également créer des fonctions sur les objets
# qui permettront de décrire le comportement d'un objet face à une instruction demandée. On nomme ce
# type de fonctions des méthodes.
# Par exemple, on pourrait créer une méthode qui nous permettrait d'afficher toutes les
# informations sur une voiture dans un texte formaté. Celle-ci nous permettra de travailler de façon plus
# générique. Nous n'aurons plus besoin de faire l'affichage systématique de chacun des attributs de l'objet,
# c'est la méthode d'affichage propre à notre objet qui s'en occupera.

# On définit les méthodes de la même façon que les méthodes que les fonctions que nous avons créées
# jusqu'à maintenant, à la seule exception que chaque méthode doit nécessairement avoir "self" comme
# premier paramètre. Ce paramètre permet en de référer l'objet courant. Par exemple:

class Voiture:
    def __init__(self):
        self.marque = ""
        self.modele = ""
        self.annee = 0
        self.km = 0.0
        self.prix = 0.0

    def imprimer_voiture(self):
        print("{} \t {} \t {} \t {} \t {}".format(
            self.marque,
            self.modele,
            self.annee,
            self.km,
            self.prix
        ))

# Ensuite, pour l'utiliser, nous utiliserons la même technique que pour les attributs:
# nom_objet.nom_methode()

# Par exemple, une_voiture.imprimer_voiture()
# Nous donnerait l'affichage de la voiture. Nous n'avons plus besoin d'écrire print(…) puisque
# la commande d'affichage à l'écran est déjà exécutée dans la méthode afficherVoiture()!

# Un exemple:
if __name__ == "__main__":
    une_voiture = Voiture()
    une_voiture.marque = "Honda"
    une_voiture.modele = "Civic"
    une_voiture.annee = 1999
    une_voiture.km = 42000
    une_voiture.prix = 17000

    une_voiture.imprimer_voiture()

# Suite dans voiturev3.py
