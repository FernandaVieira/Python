# Jusqu'à présent, nous avons défini une classe et nous avons utilisé ses objets dans elle-même.
# Il est possible de le faire mais habituellement, on définit une classe comme on vient de le faire
# et on utilise ses objets dans une ou plusieurs autres classes!

# Voici un exercice pour vous familiariser avec la POO. Pour vous aider, la structure
# de la classe est déjà créée, ainsi que le main, vous devez uniquement ajouter le
# code des méthodes et du constructeur.

# Nous aurons ici une classe Concessionnaire, qui dipose d'un inventaire de voitures
# (un dictionnaire de Voitures), d'un compte de banque (un simple float pour simplifier) et d'une marge
# qui détermine à quel pourcentage du prix original il vend les voitures aux clients.
# Le Concessionnaire peut faire trois actions:
# - acheter des voitures (Il paye le prix demandé et ajoute la voiture à son inventaire)
# - vendre des voitrures (Il reçoit le prix de la voiture + la marge et retire la voiture de son inventaire)
# - lister les voitures

# On peut importer une classe comme on importe une fonction.
from voiturev3 import Voiture

class Concessionnaire:
    def __init__(self, solde_initial, marge):
        pass
        # TODO À implémenter
        # Indice: N'oubliez pas de créer un attribut de type dictionnaire pour l'inventaire

    def acheter(self, voiture):
        """
        Le Concessionnaire tente d'acheter une voiture. Si son solde est suffisamment grand, 
        il l'achète, réduit son solde, ajoute la voiture à l'inventaire et retourne True.
        Args:
            voiture (Voiture): La Voiture à acheter.  

        Returns: (bool) True si le Concessionnaire a réussi à acheter la Voiture, false sinon.
        """
        # TODO À implémenter

    def vendre(self, no_serie):
        """
        Le Concessionnaire vend la Voiture ayant le no de série no_serie à un client. 
        Le prix de vente est le prix de la voiture plus la marge. Il retire la voiture
        de son inventaire et rajoute le prix de vente au solde.
        Args:
            no_serie (str): Le no de série de la voiture 

        Returns (Voiture): La Voiture vendue

        """
        # TODO À implémenter

    def lister_voitures(self):
        """
        Liste les voitures, le solde et la marge du Concessionnaire à l'écran
        """
        # TODO À implémenter

if __name__ == "__main__":
    concesionnaire = Concessionnaire(100000, 0.25)
    concesionnaire.lister_voitures()
    print()

    honda = Voiture("1A3D", "Honda", "Civic", 1999, 47000, 17000)
    kia = Voiture("2F5D", "Kia", "Rio", 2016, 5000, 20000)
    faucon = Voiture("F0RC3", "Faucon", "Millenium", 3508, 50000000, float("inf"))

    print("Tentative d'acheter la honda: ", concesionnaire.acheter(honda))
    concesionnaire.lister_voitures()
    print()

    print("Tentative d'acheter la kia: ", concesionnaire.acheter(kia))
    concesionnaire.lister_voitures()
    print()

    print("Tentative d'acheter le Faucon Millenium", concesionnaire.acheter(faucon))
    concesionnaire.lister_voitures()
    print()

    print("Vente de la kia")
    concesionnaire.vendre("2F5D")
    concesionnaire.lister_voitures()

# Dans le fichier concessionnairev2.py, nous allons faire de la lecture et de l'écriture dans les fichiers.
