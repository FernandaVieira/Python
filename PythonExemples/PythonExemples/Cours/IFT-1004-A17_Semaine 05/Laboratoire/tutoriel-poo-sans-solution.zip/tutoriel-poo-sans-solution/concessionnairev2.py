# Dans cette version, nous allons rajouter deux méthodes à notre Concesionnaire
# Une pour enregistrer l'inventaire dans un fichier et une autre pour faire des achats
# à partir d'une liste de voitures dans un fichier. Il est à noter ici que, pour simplifier,
# on ne gère pas les erreurs et on assume que les fichiers d'entrées existent et qu'ils sont
# dans le bon format.

# Vous devez compléter le code des deux nouvelles méthodes.
# Vous pouvez réutiliser le code que vosu avez fait dans la v1 pour le constructeur, acheter et vendre

from voiturev3 import Voiture


class Concessionnaire:
    def __init__(self, solde_initial, marge):
        pass
        # TODO À Implémenter

    def acheter(self, voiture):
        """
        Le Concessionnaire tente d'acheter une voiture. Si son solde est suffisamment grand, 
        il l'achète, réduit son solde, ajoute la voiture à l'inventaire et retourne True.
        Args:
            voiture (Voiture): La Voiture à acheter.  

        Returns: (bool) True si le Concessionnaire a réussi à acheter la Voiture, false sinon.
        """
        # TODO À Implémenter

    def vendre(self, no_serie):
        """
        Le Concessionnaire vend la Voiture ayant le no de série no_serie à un client. 
        Le prix de vente est le prix de la voiture plus la marge. Il retire la voiture
        de son inventaire et rajoute le prix de vente au solde.
        Args:
            no_serie (str): Le no de série de la voiture 

        Returns (Voiture): La Voiture vendue

        """
        # TODO À implémenter

    def lister_voitures(self):
        """
        Liste les voitures, le solde et la marge du Concessionnaire à l'écran
        """
        # TODO À implémenter

    def enregistrer_inventaire(self, nom_fichier):
        """
        Enregistre l'inventaire dans un fichier en utilisant le format CSV. 
        Dans ce format, chaque ligne représente une Voiture et les attributs sont
        séparés par des espaces.
        Args:
            nom_fichier (str): Le nom du fichier à lire
        """
        # Pour pouvoir écrire des caractères avec des accents, il faut spécifier l'encodage UTF-8
        # TODO À implémenter

    def acheter_fichier(self, nom_fichier):
        """
        Achète une liste de voitures à partir d'un fichier en format CSV. 
        Un exemple d'utilisation pourrait être que le concessionnaire 
        vient de recevoir un arrivage de voitures d'un fournisseur et que le fournisseur
        fournit les informations sur les voitures au Concessionnaire via un fichier CSV. 
        Les voitures sont donc automatiquement ajoutées à l'inventaire. 
        Args:
            nom_fichier (str): Le nom du fichier à lire.
        """

        # TODO À implémenter

if __name__ == "__main__":
    concesionnaire = Concessionnaire(100000, 0.25)

    concesionnaire.acheter_fichier("achats.csv")
    concesionnaire.lister_voitures()
    concesionnaire.enregistrer_inventaire("inventaire.csv")
