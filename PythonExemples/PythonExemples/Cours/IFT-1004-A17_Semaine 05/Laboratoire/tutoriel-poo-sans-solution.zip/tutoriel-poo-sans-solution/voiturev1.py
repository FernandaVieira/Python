# Comment procéder pour contourner le problème? Grâce à la philosophie de développement orienté objet,
# on peut créer nos propres types de variables (types de données) ayant leur propres caractéristiques…
# Ainsi, on peut créer une classe Voiture (Une classe est un modèle pour les futures
# variables ou instances) qui aura comme caractéristiques (comme attributs) la marque, le modèle,
# l’année, le kilométrage et le prix.

# On aura besoin alors de créer 5 attributs (des variables internes à la classe ou par instanciation,
# les données de l’instance ou les données de l’objet de la classe) pour représenter nos voitures.

# Ensuite, on créera des objets qui seront définis selon ces 5 valeurs…
# Chaque objet est indépendant d’un autre, il possède son propre état
# (L’état d’un objet est l’ensemble des valeurs que prennent les attributs de la classe
#  pour un objet spécifique)

# Pour définir un type d’objet, on doit créer une classe (classe == type)
# qui va décrire l’état de toutes ces instances (objets). Voici pour notre classe voiture :

class Voiture:
    def __init__(self):
        self.marque = ""
        self.modele = ""
        self.annee = 0
        self.km = 0.0
        self.prix = 0.0

# Instancier un objet

# Maintenant que la classe a été créée, on doit pouvoir utiliser des objets de type Voiture, mais
# pour les utiliser, on doit d’abord les instancier (i.e. les créer).  Pour ce faire, on utilise
# la syntaxe suivante: NomDeLaClasse(parametres_du_constructeur). Par exemple:

une_voiture = Voiture()

# Ici, on crée un objet une_voiture qui sera de type Voiture.
# À ce moment, on a affecté aucune valeur à notre objet ; il existe, mais avec les valeurs par défaut.

# Initialiser un objet

# Pour donner des valeurs à chacun des attributs de notre objet, on doit indiquer deux choses :
# 1. le nom de l’objet que l’on veut modifier
# 2. l’attribut à modifier

# Par exemple, on peut affecter les valeurs suivantes à notre véhicule honda mentionné précédemment:

une_voiture = Voiture()
une_voiture.marque = "Honda"
une_voiture.modele = "Civic"
une_voiture.annee = 1999
une_voiture.km = 42000
une_voiture.prix = 17000

# Consulter/modifier la valeur d'un attribut d'un objet

# Pour consulter ou modifier les valeurs des attributs, on utilise la même syntaxe:
# nom_objet.attribut_a_modifier
# Par exemple:

une_voiture.km += 5000 # km vaut maintenant 47000

# Un exemple d'utilisation de la classe Voiture:

if __name__ == "__main__":
    une_voiture = Voiture()
    une_voiture.marque = "Honda"
    une_voiture.modele = "Civic"
    une_voiture.annee = 1999
    une_voiture.km = 42000
    une_voiture.prix = 17000

    une_voiture.km += 5000
    print(une_voiture.marque)
    print(une_voiture.modele)
    print(une_voiture.annee)
    print(une_voiture.km)
    print(une_voiture.prix)

# Suite dans le fichier voiturev2.py
